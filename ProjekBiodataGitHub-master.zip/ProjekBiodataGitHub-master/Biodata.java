import java.util.Scanner;

public class Biodata {

    public static void main(String[] args) {
  
      
      Scanner input_bio=new Scanner (System.in);
        System.out.println("Biodata Siswa CCIT yang ikut seminar");
        System.out.println("----------------");
     
      
        
      
      System.out.println("Nama = Acika Difa");
      System.out.println("Nim = 1920013212");
        System.out.println("Kelas = 3SC1");
        System.out.println("Jurusan = Software Enginering ");
        System.out.println("\n");
        System.out.println("--- Print Biodata seminar----");
	System.out.println("----------------");
	System.out.println("Tiket Masuk");
	System.out.println("----------------");
	System.out.println("jam = 07.00");
	System.out.println("Tempat = Gedung FT UI Lt. 2");
	System.out.println("Nomor Tempat Duduk = 001-002");
	System.out.println("Tema Seminar = Blockchain and It's impact on Finance and Accounting");
    }
    }